namespace StepanovApp
{
    partial class FormStockReport
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitle      = new Label();
            lblDate       = new Label();
            dtpDate       = new DateTimePicker();
            btnRefresh    = new Button();
            btnClose      = new Button();
            dataGridView1 = new DataGridView();
            lblChartTitle = new Label();
            picChart      = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picChart).BeginInit();
            SuspendLayout();

            // ── Заголовок ─────────────────────────────────────────────────────
            lblTitle.Text     = "Отчёт по товарам (суммы запасов на дату)";
            lblTitle.Font     = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTitle.AutoSize = true;
            lblTitle.Location = new Point(12, 10);

            // ── Строка выбора даты ────────────────────────────────────────────
            lblDate.Text     = "На дату:";
            lblDate.Location = new Point(12, 50);
            lblDate.AutoSize = true;

            dtpDate.Location = new Point(75, 46);
            dtpDate.Size     = new Size(140, 23);
            dtpDate.Format   = DateTimePickerFormat.Short;

            btnRefresh.Text     = "Обновить";
            btnRefresh.Location = new Point(230, 44);
            btnRefresh.Size     = new Size(90, 27);
            btnRefresh.Click   += btnRefresh_Click;

            btnClose.Text     = "Закрыть";
            btnClose.Location = new Point(330, 44);
            btnClose.Size     = new Size(80, 27);
            btnClose.Click   += btnClose_Click;

            // ── Таблица данных ────────────────────────────────────────────────
            dataGridView1.Location           = new Point(12, 82);
            dataGridView1.Size               = new Size(750, 200);
            dataGridView1.ReadOnly           = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            // ── Заголовок графика ─────────────────────────────────────────────
            lblChartTitle.Text     = "График остатков (сумма, руб.):";
            lblChartTitle.Font     = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblChartTitle.AutoSize = true;
            lblChartTitle.Location = new Point(12, 295);

            // ── PictureBox для графика ────────────────────────────────────────
            picChart.Location    = new Point(12, 314);
            picChart.Size        = new Size(750, 220);
            picChart.BackColor   = Color.WhiteSmoke;
            picChart.BorderStyle = BorderStyle.FixedSingle;
            picChart.Paint      += picChart_Paint;

            // ── Форма ─────────────────────────────────────────────────────────
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode       = AutoScaleMode.Font;
            ClientSize          = new Size(780, 548);
            Text                = "Отчёт по запасам — Степанов";
            Controls.AddRange(new Control[]
            {
                lblTitle, lblDate, dtpDate, btnRefresh, btnClose,
                dataGridView1,
                lblChartTitle, picChart
            });
            Load += FormStockReport_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)picChart).EndInit();
            ResumeLayout(false);
        }

        private Label          lblTitle;
        private Label          lblDate;
        private DateTimePicker dtpDate;
        private Button         btnRefresh;
        private Button         btnClose;
        private DataGridView   dataGridView1;
        private Label          lblChartTitle;
        private PictureBox     picChart;
    }
}
