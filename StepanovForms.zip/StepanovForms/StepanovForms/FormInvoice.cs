using Npgsql;
using System.Data;

namespace StepanovApp
{
    public partial class FormInvoice : Form
    {
        private readonly NpgsqlConnection _con;

        // Данные для диаграммы
        private decimal _sumPaidFull;     // Полностью оплачено
        private decimal _sumPartial;      // Частично оплачено
        private decimal _sumUnpaid;       // Не оплачено
        private decimal _sumOverdue;      // Просрочено

        public FormInvoice(NpgsqlConnection con)
        {
            _con = con;
            InitializeComponent();
        }

        private void FormInvoice_Load(object sender, EventArgs e)
        {
            LoadInvoices();
        }

        // Загрузка накладных
        private void LoadInvoices()
        {
            string sql = @"
            SELECT ii.id, s.name AS ""Поставщик"", ii.data_ AS ""Дата"",
                   ii.totalsum AS ""Сумма"", ii.due_date AS ""Срок оплаты"",
                   COALESCE(p.paid,0) AS ""Оплачено"",
                   ii.totalsum - COALESCE(p.paid,0) AS ""Остаток долга""
            FROM InvoiceIn ii
            JOIN Supplier s ON s.id = ii.id_supplier
            LEFT JOIN (SELECT id_invoice, SUM(amount) AS paid FROM Payment GROUP BY id_invoice) p
                   ON p.id_invoice = ii.id
            ORDER BY ii.data_ DESC";
            var ds = new DataSet();
            new NpgsqlDataAdapter(sql, _con).Fill(ds);
            dgvInvoices.DataSource = ds.Tables[0];
            dgvInvoices.Columns["id"].Visible = false;
            dgvInvoices.AutoResizeColumns();

            // Форматировать числовые столбцы
            foreach (DataGridViewColumn col in dgvInvoices.Columns)
                if (col.Index > 2) col.DefaultCellStyle.Format = "N2";

            // Раскраска строк по статусу
            ColorizeRows(ds.Tables[0]);

            // Загрузить данные для диаграммы
            LoadChartData();
        }

        // Раскраска строк: просрочено → красный, оплачено → зелёный
        private void ColorizeRows(DataTable dt)
        {
            for (int i = 0; i < dgvInvoices.Rows.Count; i++)
            {
                var row = dt.Rows[i];

                decimal rem =
                    row["Остаток долга"] == DBNull.Value
                    ? 0
                    : Convert.ToDecimal(row["Остаток долга"]);

                decimal sum =
                    row["Сумма"] == DBNull.Value
                    ? 0
                    : Convert.ToDecimal(row["Сумма"]);

                DateTime? due = null;

                if (row["Срок оплаты"] != DBNull.Value)
                {
                    DateOnly dueDateOnly =
                        (DateOnly)row["Срок оплаты"];

                    due =
                        dueDateOnly.ToDateTime(TimeOnly.MinValue);
                }

                if (rem <= 0)
                {
                    dgvInvoices.Rows[i].DefaultCellStyle.BackColor =
                        Color.FromArgb(220, 255, 220);
                }
                else if (due.HasValue && due.Value < DateTime.Today)
                {
                    dgvInvoices.Rows[i].DefaultCellStyle.BackColor =
                        Color.FromArgb(255, 220, 220);
                }
                else if (rem < sum)
                {
                    dgvInvoices.Rows[i].DefaultCellStyle.BackColor =
                        Color.FromArgb(255, 255, 200);
                }
            }
        }

        // Загрузка данных для круговой диаграммы
        private void LoadChartData()
        {
            string sql = @"
            SELECT
                SUM(CASE WHEN (ii.totalsum - COALESCE(p.paid,0)) <= 0
                         THEN 1 ELSE 0 END)                         AS cnt_paid,
                SUM(CASE WHEN (ii.totalsum - COALESCE(p.paid,0)) > 0
                          AND COALESCE(p.paid,0) > 0
                          AND ii.due_date >= CURRENT_DATE
                         THEN 1 ELSE 0 END)                         AS cnt_partial,
                SUM(CASE WHEN COALESCE(p.paid,0) = 0
                          AND ii.due_date >= CURRENT_DATE
                         THEN 1 ELSE 0 END)                         AS cnt_unpaid,
                SUM(CASE WHEN (ii.totalsum - COALESCE(p.paid,0)) > 0
                          AND ii.due_date < CURRENT_DATE
                         THEN 1 ELSE 0 END)                         AS cnt_overdue
            FROM InvoiceIn ii
            LEFT JOIN (SELECT id_invoice, SUM(amount) AS paid
                       FROM Payment GROUP BY id_invoice) p
                   ON p.id_invoice = ii.id";

            var cmd = new NpgsqlCommand(sql, _con);
            using var r = cmd.ExecuteReader();
            if (r.Read())
            {
                _sumPaidFull = r.IsDBNull(0) ? 0 : r.GetDecimal(0);
                _sumPartial  = r.IsDBNull(1) ? 0 : r.GetDecimal(1);
                _sumUnpaid   = r.IsDBNull(2) ? 0 : r.GetDecimal(2);
                _sumOverdue  = r.IsDBNull(3) ? 0 : r.GetDecimal(3);
            }

            // Перерисовать диаграмму
            picChart.Invalidate();
        }

        // Отрисовка круговой диаграммы (Paint)
        private void picChart_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            decimal total = _sumPaidFull + _sumPartial + _sumUnpaid + _sumOverdue;

            int w = picChart.Width;
            int h = picChart.Height;

            if (total == 0)
            {
                using var fnt = new Font("Segoe UI", 9F);
                g.DrawString("Нет данных", fnt, Brushes.Gray, 30, h / 2 - 8);
                return;
            }

            // Параметры круга
            int diameter = Math.Min(w - 160, h - 40);
            if (diameter < 20) diameter = 20;
            int cx = 10, cy = (h - diameter) / 2;
            var rect = new Rectangle(cx, cy, diameter, diameter);

            var slices = new[]
            {
                (_sumPaidFull, Color.FromArgb(80, 180, 80),   "Оплачено"),
                (_sumPartial,  Color.FromArgb(255, 210, 60),  "Частично"),
                (_sumUnpaid,   Color.FromArgb(100, 160, 220), "Не оплачено"),
                (_sumOverdue,  Color.FromArgb(220, 70,  70),  "Просрочено"),
            };

            float startAngle = -90f;
            foreach (var (val, color, _) in slices)
            {
                if (val <= 0) continue;
                float sweep = (float)(val / total * 360m);
                using var brush = new SolidBrush(color);
                g.FillPie(brush, rect, startAngle, sweep);
                using var pen = new Pen(Color.White, 2);
                g.DrawPie(pen, rect, startAngle, sweep);
                startAngle += sweep;
            }

            // Легенда справа
            int lx = cx + diameter + 14;
            int ly = cy + 10;
            using var fntLeg = new Font("Segoe UI", 8.5F);
            foreach (var (val, color, label) in slices)
            {
                float pct = total > 0 ? (float)(val / total * 100m) : 0f;  
                using var br = new SolidBrush(color);
                g.FillRectangle(br, lx, ly, 14, 14);
                g.DrawRectangle(Pens.Gray, lx, ly, 14, 14);
                g.DrawString($"{label}: {(int)val} ({pct:F1}%)",
                    fntLeg, Brushes.Black, lx + 18, ly);
                ly += 26;
            }

            // Всего накладных
            g.DrawString($"Всего: {(int)total} накл.",
                new Font("Segoe UI", 8.5F, FontStyle.Bold), Brushes.Black, lx, ly + 4);
        }

        // Строки накладной
        private void LoadInvoiceItems(int invoiceId)
        {
            string sql = @"
            SELECT p.name AS ""Товар"", p.ed AS ""Ед."",
                   fi.quantity AS ""Кол-во"", fi.price AS ""Цена"",
                   fi.quantity*fi.price AS ""Сумма""
            FROM InvoiceInInfo fi
            JOIN Product p ON p.id = fi.id_product
            WHERE fi.id_invoice = :iid";
            var da = new NpgsqlDataAdapter(sql, _con);
            da.SelectCommand.Parameters.AddWithValue("iid", invoiceId);
            var ds = new DataSet();
            da.Fill(ds);
            dgvItems.DataSource = ds.Tables[0];
            dgvItems.AutoResizeColumns();
        }

        // Платежи по накладной
        private void LoadPayments(int invoiceId)
        {
            string sql = @"
            SELECT pay_date AS ""Дата платежа"", amount AS ""Сумма""
            FROM Payment WHERE id_invoice = :iid ORDER BY pay_date";
            var da = new NpgsqlDataAdapter(sql, _con);
            da.SelectCommand.Parameters.AddWithValue("iid", invoiceId);
            var ds = new DataSet();
            da.Fill(ds);
            dgvPayments.DataSource = ds.Tables[0];
            dgvPayments.AutoResizeColumns();
        }

        private void dgvInvoices_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvInvoices.CurrentRow == null) return;
            int id = Convert.ToInt32(dgvInvoices.CurrentRow.Cells["id"].Value);
            LoadInvoiceItems(id);
            LoadPayments(id);
        }

        private void btnAddInvoice_Click(object sender, EventArgs e)
        {
            new FormAddInvoice(_con).ShowDialog();
            LoadInvoices();
        }

        private void btnAddPayment_Click(object sender, EventArgs e)
        {
            if (dgvInvoices.CurrentRow == null)
            {
                MessageBox.Show("Выберите накладную.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int invoiceId = Convert.ToInt32(dgvInvoices.CurrentRow.Cells["id"].Value);
            using var frm = new FormAddPayment(_con, invoiceId);
            frm.ShowDialog();
            LoadInvoices();
            LoadPayments(invoiceId);
        }

        private void btnClose_Click(object sender, EventArgs e) => Close();
    }
}
