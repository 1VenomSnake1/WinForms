using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class AddSupplierForm : Form
    {
        public NpgsqlConnection con;
        int id;

        public AddSupplierForm(NpgsqlConnection con, int id)
        {
            this.con = con;
            this.id = id;
            InitializeComponent();
        }

        public AddSupplierForm(NpgsqlConnection con, int id, string name, string address, string phone)
        {
            InitializeComponent();
            textBoxName.Text = name;
            textBoxAddress.Text = address;
            textBoxPhone.Text = phone;
            this.con = con;
            this.id = id;
        }

        private void buttonNo_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonYes_Click(object sender, EventArgs e)
        {
            if (id == -1)
            {
                try
                {
                    NpgsqlCommand command = new NpgsqlCommand(
                        "INSERT INTO Supplier(name, address, phone) VALUES (:name, :address, :phone)", con);
                    command.Parameters.AddWithValue("name", textBoxName.Text);
                    command.Parameters.AddWithValue("address", textBoxAddress.Text);
                    command.Parameters.AddWithValue("phone", textBoxPhone.Text);
                    command.ExecuteNonQuery();
                    Close();
                }
                catch { }
            }
            else
            {
                try
                {
                    NpgsqlCommand command = new NpgsqlCommand(
                        "UPDATE Supplier SET name=:name, address=:address, phone=:phone WHERE id=:id", con);
                    command.Parameters.AddWithValue("id", id);
                    command.Parameters.AddWithValue("name", textBoxName.Text);
                    command.Parameters.AddWithValue("address", textBoxAddress.Text);
                    command.Parameters.AddWithValue("phone", textBoxPhone.Text);
                    command.ExecuteNonQuery();
                    Close();
                }
                catch { }
            }
        }
    }
}
