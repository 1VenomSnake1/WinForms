using Npgsql;
using System.Data;
using System.Diagnostics;

namespace StepanovApp
{
    public partial class FormSupplierReport : Form
    {
        private readonly NpgsqlConnection _con;

        public FormSupplierReport(NpgsqlConnection con)
        {
            _con = con;
            InitializeComponent();
        }

        private void FormSupplierReport_Load(object sender, EventArgs e)
        {
            dtpFrom.Value = DateTime.Today.AddMonths(-3);
            dtpTo.Value   = DateTime.Today;
            LoadReport();
        }

        // Загрузка данных
        private void LoadReport()
        {
            string sql = @"
            SELECT
                s.name                                                     AS ""Поставщик"",
                COALESCE(SUM(ii.totalsum),0)                              AS ""Получено товаров (руб.)"",
                COALESCE(SUM(p.paid),0)                                   AS ""Оплачено (руб.)"",
                COALESCE(SUM(ii.totalsum),0) - COALESCE(SUM(p.paid),0)   AS ""Задолженность на конец (руб.)"",
                COALESCE(SUM(
                    CASE WHEN ii.due_date < CURRENT_DATE
                              AND (ii.totalsum - COALESCE(p.paid,0)) > 0
                         THEN ii.totalsum - COALESCE(p.paid,0)
                         ELSE 0 END
                ),0)                                                       AS ""Просроченная задолженность (руб.)""
            FROM Supplier s
            LEFT JOIN InvoiceIn ii
                   ON ii.id_supplier = s.id
                  AND ii.data_ BETWEEN :dateFrom AND :dateTo
            LEFT JOIN (
                SELECT id_invoice, SUM(amount) AS paid
                FROM Payment
                GROUP BY id_invoice
            ) p ON p.id_invoice = ii.id
            GROUP BY s.id, s.name
            ORDER BY s.name;";

            var da = new NpgsqlDataAdapter(sql, _con);
            da.SelectCommand.Parameters.AddWithValue("dateFrom", dtpFrom.Value.Date);
            da.SelectCommand.Parameters.AddWithValue("dateTo",   dtpTo.Value.Date);

            var ds = new DataSet();
            da.Fill(ds);
            var dt = ds.Tables[0];

            dataGridView1.DataSource = dt;

            // Форматирование числовых столбцов
            foreach (DataGridViewColumn col in dataGridView1.Columns)
            {
                if (col.Index > 0)
                    col.DefaultCellStyle.Format = "N2";
            }
            dataGridView1.AutoResizeColumns();
        }

        // Экспорт в Excel через CSV (открывается в Excel)
        private void btnExport_Click(object sender, EventArgs e)
        {
            var sfd = new SaveFileDialog
            {
                Filter   = "Excel CSV (*.csv)|*.csv|Все файлы (*.*)|*.*",
                FileName = $"Поставщики_{dtpFrom.Value:yyyyMMdd}_{dtpTo.Value:yyyyMMdd}.csv"
            };
            if (sfd.ShowDialog() != DialogResult.OK) return;

            try
            {
                var dt = (DataTable)dataGridView1.DataSource;
                using var sw = new System.IO.StreamWriter(sfd.FileName,
                    false, System.Text.Encoding.UTF8);

                // Заголовки
                var headers = dt.Columns.Cast<DataColumn>()
                               .Select(c => $"\"{c.ColumnName}\"");
                sw.WriteLine(string.Join(";", headers));

                // Данные
                foreach (DataRow row in dt.Rows)
                {
                    var cells = row.ItemArray
                                   .Select(v => $"\"{v}\"");
                    sw.WriteLine(string.Join(";", cells));
                }

                MessageBox.Show("Файл сохранён:\n" + sfd.FileName,
                    "Экспорт выполнен", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Открыть в Excel
                Process.Start(new ProcessStartInfo(sfd.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка экспорта: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e) => LoadReport();
        private void btnClose_Click(object sender, EventArgs e)    => Close();
    }
}
