namespace StepanovApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnProducts       = new Button();
            btnSuppliers      = new Button();
            btnInvoices       = new Button();
            btnSupplierReport = new Button();
            btnStockReport    = new Button();
            label1            = new Label();
            SuspendLayout();

            // label1 - заголовок
            label1.Text      = "Магазин автозапчастей — Степанов";
            label1.Font      = new Font("Segoe UI", 13F, FontStyle.Bold);
            label1.AutoSize  = true;
            label1.Location  = new Point(160, 20);

            // btnProducts
            btnProducts.Text     = "Товары";
            btnProducts.Location = new Point(60,  80);
            btnProducts.Size     = new Size(150, 55);
            btnProducts.Click   += btnProducts_Click;

            // btnSuppliers
            btnSuppliers.Text     = "Поставщики";
            btnSuppliers.Location = new Point(240, 80);
            btnSuppliers.Size     = new Size(150, 55);
            btnSuppliers.Click   += btnSuppliers_Click;

            // btnInvoices
            btnInvoices.Text     = "Накладные";
            btnInvoices.Location = new Point(420, 80);
            btnInvoices.Size     = new Size(150, 55);
            btnInvoices.Click   += btnInvoices_Click;

            // btnSupplierReport
            btnSupplierReport.Text      = "Отчёт по\r\nпоставщикам";
            btnSupplierReport.Location  = new Point(150, 180);
            btnSupplierReport.Size      = new Size(160, 55);
            btnSupplierReport.BackColor = Color.LightSteelBlue;
            btnSupplierReport.Click    += btnSupplierReport_Click;

            // btnStockReport
            btnStockReport.Text      = "Отчёт по\r\nзапасам";
            btnStockReport.Location  = new Point(340, 180);
            btnStockReport.Size      = new Size(160, 55);
            btnStockReport.BackColor = Color.LightGreen;
            btnStockReport.Click    += btnStockReport_Click;

            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode       = AutoScaleMode.Font;
            ClientSize          = new Size(680, 290);
            Text                = "Степанов — Автозапчасти";
            Controls.AddRange(new Control[]{ label1, btnProducts, btnSuppliers,
                btnInvoices, btnSupplierReport, btnStockReport });
            Load += Form1_Load;
            ResumeLayout(false);
        }

        private Button btnProducts;
        private Button btnSuppliers;
        private Button btnInvoices;
        private Button btnSupplierReport;
        private Button btnStockReport;
        private Label  label1;
    }
}
