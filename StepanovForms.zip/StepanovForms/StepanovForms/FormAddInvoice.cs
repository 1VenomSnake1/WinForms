// ============================================================
// FormAddInvoice.cs — Добавление приходной накладной
// Выбор поставщика, дата, добавление товаров со строками
// ============================================================
using Npgsql;
using System.Data;

namespace StepanovApp
{
    public partial class FormAddInvoice : Form
    {
        private readonly NpgsqlConnection _con;
        // Временный список строк накладной (до сохранения в БД)
        private readonly DataTable _items;

        public FormAddInvoice(NpgsqlConnection con)
        {
            _con = con;
            // Таблица для временного хранения строк
            _items = new DataTable();
            _items.Columns.Add("id_product", typeof(int));
            _items.Columns.Add("Товар",      typeof(string));
            _items.Columns.Add("Ед.",        typeof(string));
            _items.Columns.Add("Кол-во",     typeof(decimal));
            _items.Columns.Add("Цена",       typeof(decimal));
            _items.Columns.Add("Сумма",      typeof(decimal));
            InitializeComponent();
        }

        private void FormAddInvoice_Load(object sender, EventArgs e)
        {
            LoadSuppliers();
            LoadProducts();
            dgvItems.DataSource = _items;
            // Скрыть служебный столбец id_product
            dgvItems.Columns["id_product"].Visible = false;
            UpdateTotal();
        }

        // -------------------------------------------------------
        // Загрузка поставщиков в ComboBox
        // -------------------------------------------------------
        private void LoadSuppliers()
        {
            var ds = new DataSet();
            new NpgsqlDataAdapter("SELECT id, name FROM Supplier ORDER BY name", _con).Fill(ds);
            cmbSupplier.DataSource    = ds.Tables[0];
            cmbSupplier.DisplayMember = "name";
            cmbSupplier.ValueMember   = "id";
        }

        // -------------------------------------------------------
        // Загрузка товаров в ComboBox строки
        // -------------------------------------------------------
        private void LoadProducts()
        {
            var ds = new DataSet();
            new NpgsqlDataAdapter("SELECT id, name, ed FROM Product ORDER BY name", _con).Fill(ds);
            cmbProduct.DataSource    = ds.Tables[0];
            cmbProduct.DisplayMember = "name";
            cmbProduct.ValueMember   = "id";
        }

        // -------------------------------------------------------
        // Добавить строку товара во временную таблицу
        // -------------------------------------------------------
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (cmbProduct.SelectedValue == null)
            {
                MessageBox.Show("Выберите товар.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtQty.Text.Replace(',', '.'),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out decimal qty) || qty <= 0)
            {
                MessageBox.Show("Введите корректное количество (> 0).", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtPrice.Text.Replace(',', '.'),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out decimal price) || price <= 0)
            {
                MessageBox.Show("Введите корректную цену (> 0).", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Данные выбранного товара
            var row      = ((DataRowView)cmbProduct.SelectedItem!).Row;
            int    pid   = (int)row["id"];
            string pname = row["name"].ToString()!;
            string ped   = row["ed"].ToString()!;

            // Проверить — такой товар уже добавлен?
            foreach (DataRow dr in _items.Rows)
            {
                if ((int)dr["id_product"] == pid)
                {
                    MessageBox.Show("Этот товар уже добавлен в накладную.", "Внимание",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            _items.Rows.Add(pid, pname, ped, qty, price, qty * price);
            UpdateTotal();
            txtQty.Clear();
            txtPrice.Clear();
        }

        // -------------------------------------------------------
        // Удалить выделенную строку из временной таблицы
        // -------------------------------------------------------
        private void btnRemoveItem_Click(object sender, EventArgs e)
        {
            if (dgvItems.CurrentRow == null || _items.Rows.Count == 0) return;
            int idx = dgvItems.CurrentRow.Index;
            if (idx >= 0 && idx < _items.Rows.Count)
            {
                _items.Rows[idx].Delete();
                _items.AcceptChanges();
                UpdateTotal();
            }
        }

        // -------------------------------------------------------
        // Пересчёт итоговой суммы
        // -------------------------------------------------------
        private void UpdateTotal()
        {
            decimal total = 0;
            foreach (DataRow dr in _items.Rows)
                if (dr.RowState != DataRowState.Deleted)
                    total += Convert.ToDecimal(dr["Сумма"]);
            lblTotal.Text = $"Итого: {total:N2} руб.";
        }

        // -------------------------------------------------------
        // Сохранить накладную в БД
        // -------------------------------------------------------
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbSupplier.SelectedValue == null)
            {
                MessageBox.Show("Выберите поставщика.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_items.Rows.Count == 0)
            {
                MessageBox.Show("Добавьте хотя бы один товар.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using var tr = _con.BeginTransaction();
            try
            {
                // 1. Вставить накладную
                var cmdInv = new NpgsqlCommand(
                    @"INSERT INTO InvoiceIn(id_supplier, data_, totalsum)
                      VALUES(:sid, :dt, 0) RETURNING id", _con, tr);
                cmdInv.Parameters.AddWithValue("sid", (int)cmbSupplier.SelectedValue);
                cmdInv.Parameters.AddWithValue("dt",  dtpDate.Value.Date);
                int invoiceId = Convert.ToInt32(cmdInv.ExecuteScalar());

                // 2. Вставить строки — триггер сам обновит totalsum
                foreach (DataRow dr in _items.Rows)
                {
                    var cmdItem = new NpgsqlCommand(
                        @"INSERT INTO InvoiceInInfo(id_invoice, id_product, quantity, price)
                          VALUES(:iid, :pid, :qty, :price)", _con, tr);
                    cmdItem.Parameters.AddWithValue("iid",   invoiceId);
                    cmdItem.Parameters.AddWithValue("pid",   (int)dr["id_product"]);
                    cmdItem.Parameters.AddWithValue("qty",   Convert.ToDecimal(dr["Кол-во"]));
                    cmdItem.Parameters.AddWithValue("price", Convert.ToDecimal(dr["Цена"]));
                    cmdItem.ExecuteNonQuery();
                }

                tr.Commit();
                MessageBox.Show($"Накладная №{invoiceId} сохранена.", "Готово",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
            }
            catch (Exception ex)
            {
                tr.Rollback();
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) => Close();
    }
}
