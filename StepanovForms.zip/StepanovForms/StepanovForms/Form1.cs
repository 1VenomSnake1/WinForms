using Npgsql;
using WinFormsApp3;

namespace StepanovApp
{
    public partial class Form1 : Form
    {
        public NpgsqlConnection con;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new NpgsqlConnection(
                "Server=localhost; Port=5432; UserID=postgres; Password=postpass; Database=CarParts");
            con.Open();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            new FormProduct(con).ShowDialog();
        }

        private void btnSuppliers_Click(object sender, EventArgs e)
        {
            new FormSupplier(con).ShowDialog();
        }

        private void btnInvoices_Click(object sender, EventArgs e)
        {
            new FormInvoice(con).ShowDialog();
        }

        private void btnSupplierReport_Click(object sender, EventArgs e)
        {
            new FormSupplierReport(con).ShowDialog();
        }

        private void btnStockReport_Click(object sender, EventArgs e)
        {
            new FormStockReport(con).ShowDialog();
        }
    }
}
