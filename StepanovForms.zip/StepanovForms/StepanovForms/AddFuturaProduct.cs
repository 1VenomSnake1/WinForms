﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class AddFuturaProduct : Form
    {
        public NpgsqlConnection con;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        int id;
        public AddFuturaProduct(NpgsqlConnection con,int id)
        {
            InitializeComponent();
            this.con = con;
            this.id = id;
        }
        private void Update()
        {
            String sql = "Select*from product";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            comboBoxProduct.DataSource = dt;
            comboBoxProduct.DisplayMember = "name";
            comboBoxProduct.ValueMember = "ID";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                NpgsqlCommand command = new NpgsqlCommand("INSERT INTO FuturaInfo (idfutura,idproduct,quantity,price)" +
                    "VALUES(:idfutura,:idproduct,:quantity,:price,0)", con);
                command.Parameters.AddWithValue("idproduct", comboBoxProduct.SelectedValue);
                command.Parameters.AddWithValue("idfutura", id);
                command.Parameters.AddWithValue("quantity", Convert.ToDouble(textBoxQ.Text));
                command.Parameters.AddWithValue("price", Convert.ToDouble(textBoxP.Text));
                command.ExecuteNonQuery();
                Close();
            }
        }

        private void AddFuturaProduct_Load(object sender, EventArgs e)
        {
            Update();
        }
    }
}
