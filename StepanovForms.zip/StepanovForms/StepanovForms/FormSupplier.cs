using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class FormSupplier : Form
    {
        public NpgsqlConnection con;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();

        public FormSupplier(NpgsqlConnection con)
        {
            this.con = con;
            InitializeComponent();
        }

        public void Update()
        {
            String sql = "SELECT * FROM Supplier";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Номер";
            dataGridView1.Columns[1].HeaderText = "Название";
            dataGridView1.Columns[2].HeaderText = "Адрес";
            dataGridView1.Columns[3].HeaderText = "Номер телефона";
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void FormSupplier_Load(object sender, EventArgs e)
        {
            Update();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddSupplierForm f = new AddSupplierForm(con, -1);
            f.ShowDialog();
            Update();
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Хотите удалить?",
                "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                int id = (int)dataGridView1.CurrentRow.Cells["id"].Value;
                NpgsqlCommand command = new NpgsqlCommand("DELETE FROM Supplier WHERE id=:id", con);
                command.Parameters.AddWithValue("id", id);
                command.ExecuteNonQuery();
                Update();
            }
        }

        private void изменитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int id = (int)dataGridView1.CurrentRow.Cells["id"].Value;
            string name = (string)dataGridView1.CurrentRow.Cells["name"].Value;
            string address = dataGridView1.CurrentRow.Cells["address"].Value as string ?? "";
            string phone = dataGridView1.CurrentRow.Cells["phone"].Value as string ?? "";
            AddSupplierForm f = new AddSupplierForm(con, id, name, address, phone);
            f.ShowDialog();
            Update();
        }
    }
}
