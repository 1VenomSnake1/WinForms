// ============================================================
// FormAddPayment.cs — Добавление платежа по накладной
// Показывает: сумму накладной, уже оплачено, остаток долга
// Проверяет: платёж не превышает остаток
//            дата платежа в пределах 2 месяцев от даты накладной
// ============================================================
using Npgsql;

namespace StepanovApp
{
    public partial class FormAddPayment : Form
    {
        private readonly NpgsqlConnection _con;
        private readonly int              _invoiceId;
        private decimal _totalSum;
        private decimal _alreadyPaid;
        private decimal _remaining;
        private DateTime _invoiceDate;

        public FormAddPayment(NpgsqlConnection con, int invoiceId)
        {
            _con       = con;
            _invoiceId = invoiceId;
            InitializeComponent();
        }

        private void FormAddPayment_Load(object sender, EventArgs e)
        {
            LoadInvoiceInfo();
        }

        // -------------------------------------------------------
        // Загрузить информацию о накладной
        // -------------------------------------------------------
        private void LoadInvoiceInfo()
        {
            string sql = @"
SELECT ii.data_, ii.totalsum, ii.due_date,
       COALESCE(p.paid, 0) AS paid,
       s.name              AS supplier
FROM InvoiceIn ii
JOIN Supplier s ON s.id = ii.id_supplier
LEFT JOIN (
    SELECT id_invoice, SUM(amount) AS paid
    FROM Payment GROUP BY id_invoice
) p ON p.id_invoice = ii.id
WHERE ii.id = :iid";
            var cmd = new NpgsqlCommand(sql, _con);
            cmd.Parameters.AddWithValue("iid", _invoiceId);

            using var reader = cmd.ExecuteReader();
            if (!reader.Read()) return;

            _invoiceDate = reader.GetDateTime(0);
            _totalSum    = reader.GetDecimal(1);
            var dueDate  = reader.GetDateTime(2);
            _alreadyPaid = reader.GetDecimal(3);
            string supplier = reader.GetString(4);
            _remaining   = _totalSum - _alreadyPaid;
            reader.Close();

            // Заполнить информационные метки
            lblInvoiceNo.Text  = $"Накладная №{_invoiceId}  |  Поставщик: {supplier}";
            lblTotal.Text      = $"Сумма накладной:  {_totalSum:N2} руб.";
            lblPaid.Text       = $"Уже оплачено:       {_alreadyPaid:N2} руб.";
            lblRemaining.Text  = $"Остаток долга:      {_remaining:N2} руб.";
            lblDueDate.Text    = $"Срок оплаты:         {dueDate:dd.MM.yyyy}";

            // Выделить красным если долг просрочен
            if (dueDate < DateTime.Today && _remaining > 0)
            {
                lblDueDate.ForeColor = Color.Red;
                lblDueDate.Font      = new Font(lblDueDate.Font, FontStyle.Bold);
            }

            // Установить максимальную дату платежа = due_date
            dtpPayDate.MaxDate = dueDate > DateTime.Today ? dueDate : DateTime.Today;
            dtpPayDate.Value   = DateTime.Today;

            // Если долг уже погашен — сообщить
            if (_remaining <= 0)
            {
                txtAmount.Enabled  = false;
                btnSave.Enabled    = false;
                lblRemaining.ForeColor = Color.Green;
                lblRemaining.Text  = "Накладная полностью оплачена ✓";
            }
        }

        // -------------------------------------------------------
        // Подсказка: ввод суммы — показать «Будет остаток»
        // -------------------------------------------------------
        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            if (decimal.TryParse(txtAmount.Text.Replace(',', '.'),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out decimal amt))
            {
                decimal afterPay = _remaining - amt;
                lblAfterPay.Text = afterPay >= 0
                    ? $"После платежа останется: {afterPay:N2} руб."
                    : "⚠ Сумма превышает остаток долга!";
                lblAfterPay.ForeColor = afterPay >= 0 ? Color.DarkBlue : Color.Red;
            }
            else
            {
                lblAfterPay.Text = "";
            }
        }

        // -------------------------------------------------------
        // Сохранить платёж
        // -------------------------------------------------------
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txtAmount.Text.Replace(',', '.'),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out decimal amt) || amt <= 0)
            {
                MessageBox.Show("Введите корректную сумму платежа (> 0).", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (amt > _remaining)
            {
                MessageBox.Show($"Сумма платежа ({amt:N2} руб.) превышает остаток долга " +
                                $"({_remaining:N2} руб.).", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверка срока: дата платежа не позже due_date
            DateTime payDate = dtpPayDate.Value.Date;

            try
            {
                var cmd = new NpgsqlCommand(
                    "INSERT INTO Payment(id_invoice, pay_date, amount) VALUES(:iid, :dt, :amt)",
                    _con);
                cmd.Parameters.AddWithValue("iid", _invoiceId);
                cmd.Parameters.AddWithValue("dt",  payDate);
                cmd.Parameters.AddWithValue("amt", amt);
                cmd.ExecuteNonQuery();

                MessageBox.Show($"Платёж на сумму {amt:N2} руб. записан.", "Готово",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) => Close();
    }
}
