namespace StepanovApp
{
    partial class FormSupplierReport
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblFrom       = new Label();
            lblTo         = new Label();
            dtpFrom       = new DateTimePicker();
            dtpTo         = new DateTimePicker();
            btnRefresh    = new Button();
            btnExport     = new Button();
            btnClose      = new Button();
            dataGridView1 = new DataGridView();
            lblTitle      = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();

            lblTitle.Text      = "Отчёт по поставщикам (задолженность)";
            lblTitle.Font      = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTitle.AutoSize  = true;
            lblTitle.Location  = new Point(12, 10);

            lblFrom.Text     = "С:";
            lblFrom.Location = new Point(12, 50);
            lblFrom.AutoSize = true;

            dtpFrom.Location = new Point(40, 46);
            dtpFrom.Size     = new Size(140, 23);
            dtpFrom.Format   = DateTimePickerFormat.Short;

            lblTo.Text     = "По:";
            lblTo.Location = new Point(195, 50);
            lblTo.AutoSize = true;

            dtpTo.Location = new Point(225, 46);
            dtpTo.Size     = new Size(140, 23);
            dtpTo.Format   = DateTimePickerFormat.Short;

            btnRefresh.Text     = "Обновить";
            btnRefresh.Location = new Point(380, 44);
            btnRefresh.Size     = new Size(90, 27);
            btnRefresh.Click   += btnRefresh_Click;

            btnExport.Text      = "Экспорт Excel";
            btnExport.Location  = new Point(480, 44);
            btnExport.Size      = new Size(110, 27);
            btnExport.BackColor = Color.LightGreen;
            btnExport.Click    += btnExport_Click;

            btnClose.Text     = "Закрыть";
            btnClose.Location = new Point(600, 44);
            btnClose.Size     = new Size(80, 27);
            btnClose.Click   += btnClose_Click;

            dataGridView1.Location              = new Point(12, 82);
            dataGridView1.Size                  = new Size(960, 400);
            dataGridView1.ReadOnly              = true;
            dataGridView1.AllowUserToAddRows    = false;
            dataGridView1.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode       = AutoScaleMode.Font;
            ClientSize          = new Size(990, 510);
            Text                = "Отчёт по поставщикам — Степанов";
            Controls.AddRange(new Control[]{ lblTitle, lblFrom, dtpFrom,
                lblTo, dtpTo, btnRefresh, btnExport, btnClose, dataGridView1 });
            Load += FormSupplierReport_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        private Label          lblTitle;
        private Label          lblFrom;
        private Label          lblTo;
        private DateTimePicker dtpFrom;
        private DateTimePicker dtpTo;
        private Button         btnRefresh;
        private Button         btnExport;
        private Button         btnClose;
        private DataGridView   dataGridView1;
    }
}
