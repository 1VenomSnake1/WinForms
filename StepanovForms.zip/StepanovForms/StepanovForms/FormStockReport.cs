using Npgsql;
using System.Data;

namespace StepanovApp
{
    public partial class FormStockReport : Form
    {
        private readonly NpgsqlConnection _con;

        // Данные для графика
        private List<(string Name, decimal Amount)> _chartData = new();

        public FormStockReport(NpgsqlConnection con)
        {
            _con = con;
            InitializeComponent();
        }

        private void FormStockReport_Load(object sender, EventArgs e)
        {
            dtpDate.Value = DateTime.Today;
            LoadReport();
        }

        private void LoadReport()
        {
            string sql = @"
            SELECT
                p.name                                            AS ""Товар"",
                p.ed                                              AS ""Ед.изм."",
                COALESCE(SUM(iii.quantity),0)
                    - COALESCE(SUM(ooo.quantity),0)               AS ""Остаток (кол-во)"",
                COALESCE(SUM(iii.quantity * iii.price),0)
                    - COALESCE(SUM(ooo.quantity * ooo.price),0)   AS ""Остаток (сумма, руб.)""
            FROM Product p
            LEFT JOIN InvoiceInInfo  iii
                   ON iii.id_product = p.id
                  AND iii.id_invoice IN (
                        SELECT id FROM InvoiceIn WHERE data_ <= :ondate)
            LEFT JOIN InvoiceOutInfo ooo
                   ON ooo.id_product = p.id
                  AND ooo.id_invoice IN (
                        SELECT id FROM InvoiceOut WHERE data_ <= :ondate)
            GROUP BY p.id, p.name, p.ed
            ORDER BY p.name;";

            var da = new NpgsqlDataAdapter(sql, _con);
            da.SelectCommand.Parameters.AddWithValue("ondate", dtpDate.Value.Date);

            var ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            foreach (DataGridViewColumn col in dataGridView1.Columns)
                if (col.Index >= 2) col.DefaultCellStyle.Format = "N2";
            dataGridView1.AutoResizeColumns();

            // Заполнить данные для графика
            _chartData.Clear();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                string name   = row["Товар"].ToString() ?? "";
                decimal amount = row["Остаток (сумма, руб.)"] == DBNull.Value
                    ? 0m
                    : Convert.ToDecimal(row["Остаток (сумма, руб.)"]);
                _chartData.Add((name, amount));
            }

            picChart.Invalidate();
        }

        //Отрисовка столбчатого графика
        private void picChart_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            int w = picChart.Width;
            int h = picChart.Height;

            if (_chartData.Count == 0)
            {
                using var fntEmpty = new Font("Segoe UI", 9F);
                g.DrawString("Нет данных", fntEmpty, Brushes.Gray, w / 2 - 30, h / 2 - 8);
                return;
            }

            // Отступы для осей
            const int padLeft   = 80;
            const int padRight  = 20;
            const int padTop    = 20;
            const int padBottom = 60;

            int chartW = w - padLeft - padRight;
            int chartH = h - padTop  - padBottom;

            // Максимальная сумма 
            decimal maxVal = _chartData.Max(d => d.Amount);
            if (maxVal <= 0) maxVal = 1;

            //Фон области графика
            g.FillRectangle(Brushes.White,
                padLeft, padTop, chartW, chartH);

            // Горизонтальные линии сетки
            int gridLines = 5;
            using var penGrid = new Pen(Color.FromArgb(220, 220, 220), 1);
            using var fntAxis = new Font("Segoe UI", 7.5F);

            for (int i = 0; i <= gridLines; i++)
            {
                decimal val = maxVal * i / gridLines;
                int     py  = padTop + chartH - (int)(chartH * i / gridLines);

                g.DrawLine(penGrid, padLeft, py, padLeft + chartW, py);

                string label = val >= 1000
                    ? $"{val / 1000:N1}к"
                    : $"{val:N0}";
                var sz = g.MeasureString(label, fntAxis);
                g.DrawString(label, fntAxis, Brushes.Black,
                    padLeft - sz.Width - 4, py - sz.Height / 2);
            }

            //Ось Y
            using var penAxis = new Pen(Color.Black, 1.5f);
            g.DrawLine(penAxis, padLeft, padTop, padLeft, padTop + chartH);

            //Ось X
            g.DrawLine(penAxis, padLeft, padTop + chartH,
                padLeft + chartW, padTop + chartH);

            //Столбцы
            int   n          = _chartData.Count;
            int   barSpacing = 10;
            int   totalBars  = chartW - barSpacing;
            int   barWidth   = Math.Max(10, totalBars / n - barSpacing);
            int   step       = (chartW) / n;

            // Палитра цветов
            Color[] palette =
            {
                Color.FromArgb(70,  130, 210),
                Color.FromArgb(80,  185,  90),
                Color.FromArgb(230, 150,  50),
                Color.FromArgb(190,  75,  75),
                Color.FromArgb(140,  90, 180),
                Color.FromArgb(60,  180, 170),
            };

            using var fntValue  = new Font("Segoe UI", 7.5F);
            using var fntLabelX = new Font("Segoe UI", 8F);

            for (int i = 0; i < n; i++)
            {
                var (name, amount) = _chartData[i];

                int barH  = amount > 0
                    ? (int)(chartH * amount / maxVal)
                    : 0;
                int bx    = padLeft + i * step + (step - barWidth) / 2;
                int by    = padTop  + chartH - barH;

                Color col = palette[i % palette.Length];

                // Тень
                using (var brShadow = new SolidBrush(Color.FromArgb(40, 0, 0, 0)))
                    g.FillRectangle(brShadow, bx + 3, by + 3, barWidth, barH);

                // Столбец с градиентом
                using (var br = new System.Drawing.Drawing2D.LinearGradientBrush(
                    new Rectangle(bx, by, barWidth, Math.Max(barH, 1)),
                    col,
                    Color.FromArgb(
                        Math.Min(col.R + 60, 255),
                        Math.Min(col.G + 60, 255),
                        Math.Min(col.B + 60, 255)),
                    System.Drawing.Drawing2D.LinearGradientMode.Horizontal))
                {
                    g.FillRectangle(br, bx, by, barWidth, barH);
                }

                // Рамка столбца
                using (var penBar = new Pen(Color.FromArgb(col.R - 40 < 0 ? 0 : col.R - 40,
                                                           col.G - 40 < 0 ? 0 : col.G - 40,
                                                           col.B - 40 < 0 ? 0 : col.B - 40), 1))
                    g.DrawRectangle(penBar, bx, by, barWidth, barH);

                // Подпись суммы над столбцом
                if (barH > 0)
                {
                    string valLabel = amount >= 1000
                        ? $"{amount / 1000:N1}к"
                        : $"{amount:N0}";
                    var valSz = g.MeasureString(valLabel, fntValue);
                    g.DrawString(valLabel, fntValue, Brushes.Black,
                        bx + (barWidth - valSz.Width) / 2,
                        by - valSz.Height - 2);
                }

                // Подпись товара по оси X (с переносом по словам)
                int labelX = bx + barWidth / 2;
                int labelY = padTop + chartH + 6;
                DrawRotatedLabel(g, name, fntLabelX, labelX, labelY, barWidth + barSpacing);
            }

            //Заголовок
            using var fntTitle = new Font("Segoe UI", 9F, FontStyle.Bold);
            string title = $"Остатки товаров на {dtpDate.Value:dd.MM.yyyy} (руб.)";
            var titleSz  = g.MeasureString(title, fntTitle);
            g.DrawString(title, fntTitle, Brushes.Black,
                padLeft + (chartW - titleSz.Width) / 2, 2);
        }

        // Рисует текст вертикально под столбцом
        private static void DrawRotatedLabel(Graphics g, string text,
            Font font, int cx, int y, int maxWidth)
        {
            g.TranslateTransform(cx, y);
            g.RotateTransform(-40f);
            g.DrawString(text, font, Brushes.Black, 0, 0);
            g.ResetTransform();
        }

        private void btnRefresh_Click(object sender, EventArgs e) => LoadReport();
        private void btnClose_Click(object sender, EventArgs e)    => Close();
    }
}
