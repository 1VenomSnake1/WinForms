namespace StepanovApp
{
    partial class FormAddInvoice
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitle      = new Label();
            lblSupplier   = new Label();
            lblDate       = new Label();
            cmbSupplier   = new ComboBox();
            dtpDate       = new DateTimePicker();

            grpItem       = new GroupBox();
            lblProduct    = new Label();
            lblQty        = new Label();
            lblPrice      = new Label();
            cmbProduct    = new ComboBox();
            txtQty        = new TextBox();
            txtPrice      = new TextBox();
            btnAddItem    = new Button();
            btnRemoveItem = new Button();

            lblItemsTitle = new Label();
            dgvItems      = new DataGridView();
            lblTotal      = new Label();

            btnSave       = new Button();
            btnCancel     = new Button();

            ((System.ComponentModel.ISupportInitialize)dgvItems).BeginInit();
            grpItem.SuspendLayout();
            SuspendLayout();

            // ── Заголовок ─────────────────────────────────────
            lblTitle.Text      = "Новая приходная накладная";
            lblTitle.Font      = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTitle.AutoSize  = true;
            lblTitle.Location  = new Point(12, 10);

            // ── Поставщик ─────────────────────────────────────
            lblSupplier.Text     = "Поставщик:";
            lblSupplier.AutoSize = true;
            lblSupplier.Location = new Point(12, 50);

            cmbSupplier.Location         = new Point(110, 46);
            cmbSupplier.Size             = new Size(280, 23);
            cmbSupplier.DropDownStyle    = ComboBoxStyle.DropDownList;
            cmbSupplier.FormattingEnabled = true;

            // ── Дата ──────────────────────────────────────────
            lblDate.Text     = "Дата:";
            lblDate.AutoSize = true;
            lblDate.Location = new Point(410, 50);

            dtpDate.Location = new Point(450, 46);
            dtpDate.Size     = new Size(150, 23);
            dtpDate.Format   = DateTimePickerFormat.Short;

            // ── GroupBox: добавление строки ───────────────────
            grpItem.Text     = "Добавить позицию";
            grpItem.Location = new Point(12, 80);
            grpItem.Size     = new Size(750, 80);

            lblProduct.Text     = "Товар:";
            lblProduct.AutoSize = true;
            lblProduct.Location = new Point(10, 28);
            grpItem.Controls.Add(lblProduct);

            cmbProduct.Location          = new Point(60, 24);
            cmbProduct.Size              = new Size(220, 23);
            cmbProduct.DropDownStyle     = ComboBoxStyle.DropDownList;
            cmbProduct.FormattingEnabled = true;
            grpItem.Controls.Add(cmbProduct);

            lblQty.Text     = "Кол-во:";
            lblQty.AutoSize = true;
            lblQty.Location = new Point(295, 28);
            grpItem.Controls.Add(lblQty);

            txtQty.Location = new Point(348, 24);
            txtQty.Size     = new Size(80, 23);
            grpItem.Controls.Add(txtQty);

            lblPrice.Text     = "Цена:";
            lblPrice.AutoSize = true;
            lblPrice.Location = new Point(440, 28);
            grpItem.Controls.Add(lblPrice);

            txtPrice.Location = new Point(480, 24);
            txtPrice.Size     = new Size(90, 23);
            grpItem.Controls.Add(txtPrice);

            btnAddItem.Text      = "＋ Добавить";
            btnAddItem.Location  = new Point(582, 22);
            btnAddItem.Size      = new Size(90, 27);
            btnAddItem.BackColor = Color.LightGreen;
            btnAddItem.Click    += btnAddItem_Click;
            grpItem.Controls.Add(btnAddItem);

            btnRemoveItem.Text      = "✕ Убрать";
            btnRemoveItem.Location  = new Point(680, 22);
            btnRemoveItem.Size      = new Size(62, 27);
            btnRemoveItem.BackColor = Color.LightCoral;
            btnRemoveItem.Click    += btnRemoveItem_Click;
            grpItem.Controls.Add(btnRemoveItem);

            // ── Таблица строк ─────────────────────────────────
            lblItemsTitle.Text      = "Состав накладной:";
            lblItemsTitle.Font      = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblItemsTitle.AutoSize  = true;
            lblItemsTitle.Location  = new Point(12, 172);

            dgvItems.Location              = new Point(12, 190);
            dgvItems.Size                  = new Size(750, 220);
            dgvItems.ReadOnly              = true;
            dgvItems.AllowUserToAddRows    = false;
            dgvItems.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvItems.SelectionMode         = DataGridViewSelectionMode.FullRowSelect;

            // ── Итого ─────────────────────────────────────────
            lblTotal.Text      = "Итого: 0,00 руб.";
            lblTotal.Font      = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblTotal.AutoSize  = true;
            lblTotal.Location  = new Point(12, 420);
            lblTotal.ForeColor = Color.DarkBlue;

            // ── Кнопки сохранить / отмена ─────────────────────
            btnSave.Text      = "Сохранить накладную";
            btnSave.Location  = new Point(490, 418);
            btnSave.Size      = new Size(160, 30);
            btnSave.BackColor = Color.LightGreen;
            btnSave.Font      = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSave.Click    += btnSave_Click;

            btnCancel.Text     = "Отмена";
            btnCancel.Location = new Point(660, 418);
            btnCancel.Size     = new Size(100, 30);
            btnCancel.Click   += btnCancel_Click;

            // ── Форма ─────────────────────────────────────────
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode       = AutoScaleMode.Font;
            ClientSize          = new Size(778, 465);
            Text                = "Добавить накладную — Степанов";
            Controls.AddRange(new Control[]
            {
                lblTitle,
                lblSupplier, cmbSupplier,
                lblDate, dtpDate,
                grpItem,
                lblItemsTitle, dgvItems,
                lblTotal,
                btnSave, btnCancel
            });
            Load += FormAddInvoice_Load;
            grpItem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvItems).EndInit();
            ResumeLayout(false);
        }

        private Label          lblTitle;
        private Label          lblSupplier;
        private Label          lblDate;
        private ComboBox       cmbSupplier;
        private DateTimePicker dtpDate;
        private GroupBox       grpItem;
        private Label          lblProduct;
        private Label          lblQty;
        private Label          lblPrice;
        private ComboBox       cmbProduct;
        private TextBox        txtQty;
        private TextBox        txtPrice;
        private Button         btnAddItem;
        private Button         btnRemoveItem;
        private Label          lblItemsTitle;
        private DataGridView   dgvItems;
        private Label          lblTotal;
        private Button         btnSave;
        private Button         btnCancel;
    }
}
