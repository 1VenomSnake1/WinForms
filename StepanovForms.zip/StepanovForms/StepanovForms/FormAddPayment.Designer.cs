namespace StepanovApp
{
    partial class FormAddPayment
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            pnlInfo      = new Panel();
            lblInvoiceNo = new Label();
            lblTotal     = new Label();
            lblPaid      = new Label();
            lblRemaining = new Label();
            lblDueDate   = new Label();

            grpPay       = new GroupBox();
            lblAmountLbl = new Label();
            lblDateLbl   = new Label();
            txtAmount    = new TextBox();
            dtpPayDate   = new DateTimePicker();
            lblAfterPay  = new Label();

            btnSave      = new Button();
            btnCancel    = new Button();

            pnlInfo.SuspendLayout();
            grpPay.SuspendLayout();
            SuspendLayout();

            // ── Информационная панель ──────────────────────────
            pnlInfo.Location  = new Point(12, 12);
            pnlInfo.Size      = new Size(510, 150);
            pnlInfo.BackColor = Color.AliceBlue;
            pnlInfo.BorderStyle = BorderStyle.FixedSingle;

            lblInvoiceNo.Text      = "";
            lblInvoiceNo.Font      = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblInvoiceNo.AutoSize  = true;
            lblInvoiceNo.Location  = new Point(10, 10);
            pnlInfo.Controls.Add(lblInvoiceNo);

            lblTotal.Text     = "";
            lblTotal.AutoSize = true;
            lblTotal.Location = new Point(10, 38);
            lblTotal.Font     = new Font("Segoe UI", 9F);
            pnlInfo.Controls.Add(lblTotal);

            lblPaid.Text     = "";
            lblPaid.AutoSize = true;
            lblPaid.Location = new Point(10, 60);
            lblPaid.Font     = new Font("Segoe UI", 9F);
            pnlInfo.Controls.Add(lblPaid);

            lblRemaining.Text      = "";
            lblRemaining.AutoSize  = true;
            lblRemaining.Location  = new Point(10, 82);
            lblRemaining.Font      = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblRemaining.ForeColor = Color.DarkRed;
            pnlInfo.Controls.Add(lblRemaining);

            lblDueDate.Text     = "";
            lblDueDate.AutoSize = true;
            lblDueDate.Location = new Point(10, 108);
            lblDueDate.Font     = new Font("Segoe UI", 9F);
            pnlInfo.Controls.Add(lblDueDate);

            // ── GroupBox: ввод платежа ─────────────────────────
            grpPay.Text     = "Новый платёж";
            grpPay.Location = new Point(12, 175);
            grpPay.Size     = new Size(510, 130);
            grpPay.Font     = new Font("Segoe UI", 9F, FontStyle.Bold);

            lblAmountLbl.Text     = "Сумма платежа (руб.):";
            lblAmountLbl.AutoSize = true;
            lblAmountLbl.Location = new Point(15, 32);
            lblAmountLbl.Font     = new Font("Segoe UI", 9F);
            grpPay.Controls.Add(lblAmountLbl);

            txtAmount.Location       = new Point(175, 28);
            txtAmount.Size           = new Size(130, 23);
            txtAmount.Font           = new Font("Segoe UI", 10F);
            txtAmount.TextChanged   += txtAmount_TextChanged;
            grpPay.Controls.Add(txtAmount);

            lblDateLbl.Text     = "Дата платежа:";
            lblDateLbl.AutoSize = true;
            lblDateLbl.Location = new Point(15, 68);
            lblDateLbl.Font     = new Font("Segoe UI", 9F);
            grpPay.Controls.Add(lblDateLbl);

            dtpPayDate.Location = new Point(175, 64);
            dtpPayDate.Size     = new Size(150, 23);
            dtpPayDate.Format   = DateTimePickerFormat.Short;
            grpPay.Controls.Add(dtpPayDate);

            lblAfterPay.Text     = "";
            lblAfterPay.AutoSize = true;
            lblAfterPay.Location = new Point(15, 100);
            lblAfterPay.Font     = new Font("Segoe UI", 9F, FontStyle.Italic);
            grpPay.Controls.Add(lblAfterPay);

            // ── Кнопки ────────────────────────────────────────
            btnSave.Text      = "Записать платёж";
            btnSave.Location  = new Point(280, 320);
            btnSave.Size      = new Size(130, 32);
            btnSave.BackColor = Color.LightGreen;
            btnSave.Font      = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSave.Click    += btnSave_Click;

            btnCancel.Text     = "Отмена";
            btnCancel.Location = new Point(420, 320);
            btnCancel.Size     = new Size(100, 32);
            btnCancel.Click   += btnCancel_Click;

            // ── Форма ─────────────────────────────────────────
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode       = AutoScaleMode.Font;
            ClientSize          = new Size(538, 370);
            Text                = "Добавить платёж — Степанов";
            FormBorderStyle     = FormBorderStyle.FixedDialog;
            MaximizeBox         = false;
            Controls.AddRange(new Control[]
            {
                pnlInfo, grpPay, btnSave, btnCancel
            });
            Load += FormAddPayment_Load;
            pnlInfo.ResumeLayout(false);
            grpPay.ResumeLayout(false);
            ResumeLayout(false);
        }

        private Panel          pnlInfo;
        private Label          lblInvoiceNo;
        private Label          lblTotal;
        private Label          lblPaid;
        private Label          lblRemaining;
        private Label          lblDueDate;
        private GroupBox       grpPay;
        private Label          lblAmountLbl;
        private Label          lblDateLbl;
        private TextBox        txtAmount;
        private DateTimePicker dtpPayDate;
        private Label          lblAfterPay;
        private Button         btnSave;
        private Button         btnCancel;
    }
}
