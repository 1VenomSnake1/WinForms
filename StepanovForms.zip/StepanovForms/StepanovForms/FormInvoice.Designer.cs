namespace StepanovApp
{
    partial class FormInvoice
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblInvoices   = new Label();
            lblItems      = new Label();
            lblPayments   = new Label();
            lblChartTitle = new Label();
            dgvInvoices   = new DataGridView();
            dgvItems      = new DataGridView();
            dgvPayments   = new DataGridView();
            picChart      = new PictureBox();
            btnAddInvoice = new Button();
            btnAddPayment = new Button();
            btnClose      = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvInvoices).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvItems).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPayments).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picChart).BeginInit();
            SuspendLayout();

            // ── Накладные (верх) ─────────────────────────────
            lblInvoices.Text     = "Приходные накладные:";
            lblInvoices.Font     = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblInvoices.AutoSize = true;
            lblInvoices.Location = new Point(12, 10);

            dgvInvoices.Location           = new Point(12, 28);
            dgvInvoices.Size               = new Size(980, 190);
            dgvInvoices.ReadOnly           = true;
            dgvInvoices.AllowUserToAddRows = false;
            dgvInvoices.SelectionMode      = DataGridViewSelectionMode.FullRowSelect;
            dgvInvoices.MultiSelect        = false;
            dgvInvoices.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvInvoices.SelectionChanged  += dgvInvoices_SelectionChanged;

            // ── Кнопки управления ────────────────────────────
            btnAddInvoice.Text     = "＋ Добавить накладную";
            btnAddInvoice.Location = new Point(12, 228);
            btnAddInvoice.Size     = new Size(165, 28);
            btnAddInvoice.Click   += btnAddInvoice_Click;

            btnAddPayment.Text      = "💳 Добавить платёж";
            btnAddPayment.Location  = new Point(187, 228);
            btnAddPayment.Size      = new Size(155, 28);
            btnAddPayment.BackColor = Color.LightGreen;
            btnAddPayment.Click    += btnAddPayment_Click;

            btnClose.Text     = "Закрыть";
            btnClose.Location = new Point(352, 228);
            btnClose.Size     = new Size(80, 28);
            btnClose.Click   += btnClose_Click;

            // ── Товары накладной (левый низ) ─────────────────
            lblItems.Text     = "Товары накладной:";
            lblItems.Font     = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblItems.AutoSize = true;
            lblItems.Location = new Point(12, 268);

            dgvItems.Location           = new Point(12, 286);
            dgvItems.Size               = new Size(430, 190);
            dgvItems.ReadOnly           = true;
            dgvItems.AllowUserToAddRows = false;
            dgvItems.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            // ── Платежи (центр низ) ───────────────────────────
            lblPayments.Text     = "Платежи по накладной:";
            lblPayments.Font     = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblPayments.AutoSize = true;
            lblPayments.Location = new Point(454, 268);

            dgvPayments.Location           = new Point(454, 286);
            dgvPayments.Size               = new Size(265, 190);
            dgvPayments.ReadOnly           = true;
            dgvPayments.AllowUserToAddRows = false;
            dgvPayments.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            // ── Круговая диаграмма (правый низ) ─────────────
            lblChartTitle.Text      = "Статистика накладных:";
            lblChartTitle.Font      = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblChartTitle.AutoSize  = true;
            lblChartTitle.Location  = new Point(730, 268);

            picChart.Location    = new Point(730, 286);
            picChart.Size        = new Size(262, 190);
            picChart.BackColor   = Color.White;
            picChart.BorderStyle = BorderStyle.FixedSingle;
            picChart.Paint      += picChart_Paint;

            // ── Форма ────────────────────────────────────────
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode       = AutoScaleMode.Font;
            ClientSize          = new Size(1005, 490);
            Text                = "Накладные — Степанов";
            Controls.AddRange(new Control[]
            {
                lblInvoices, dgvInvoices,
                btnAddInvoice, btnAddPayment, btnClose,
                lblItems, dgvItems,
                lblPayments, dgvPayments,
                lblChartTitle, picChart
            });
            Load += FormInvoice_Load;
            ((System.ComponentModel.ISupportInitialize)dgvInvoices).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvItems).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPayments).EndInit();
            ((System.ComponentModel.ISupportInitialize)picChart).EndInit();
            ResumeLayout(false);
        }

        private Label        lblInvoices;
        private Label        lblItems;
        private Label        lblPayments;
        private Label        lblChartTitle;
        private DataGridView dgvInvoices;
        private DataGridView dgvItems;
        private DataGridView dgvPayments;
        private PictureBox   picChart;
        private Button       btnAddInvoice;
        private Button       btnAddPayment;
        private Button       btnClose;
    }
}
