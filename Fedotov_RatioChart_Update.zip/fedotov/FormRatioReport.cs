// ============================================================
// FormRatioReport.cs — ДИАГРАММА (Задача Федотова)
// За период по выбранным товарам:
// Круговая диаграмма соотношения заказанных и доставленных сумм
// ============================================================
using Npgsql;
using System.Data;

namespace FedotovApp
{
    public partial class FormRatioReport : Form
    {
        private readonly NpgsqlConnection _con;

        // Данные для диаграммы — список (название товара, заказано, доставлено)
        private List<(string Name, decimal Ordered, decimal Delivered)> _chartData = new();
        private decimal _totalOrdered;
        private decimal _totalDelivered;

        public FormRatioReport(NpgsqlConnection con)
        {
            _con = con;
            InitializeComponent();
        }

        private void FormRatioReport_Load(object sender, EventArgs e)
        {
            dtpFrom.Value = DateTime.Today.AddMonths(-3);
            dtpTo.Value   = DateTime.Today;
            LoadProducts();
            LoadAndDraw();
        }

        // -------------------------------------------------------
        // Заполнить CheckedListBox товарами
        // -------------------------------------------------------
        private void LoadProducts()
        {
            var ds = new DataSet();
            new NpgsqlDataAdapter("SELECT id, name FROM Product ORDER BY name", _con).Fill(ds);
            clbProducts.Items.Clear();
            foreach (DataRow row in ds.Tables[0].Rows)
                clbProducts.Items.Add(
                    new ProductItem((int)row["id"], row["name"].ToString()!), true);
        }

        // -------------------------------------------------------
        // Загрузить данные и перерисовать диаграмму
        // -------------------------------------------------------
        private void LoadAndDraw()
        {
            var ids = clbProducts.CheckedItems
                .Cast<ProductItem>()
                .Select(p => p.Id)
                .ToList();

            _chartData.Clear();
            _totalOrdered   = 0;
            _totalDelivered = 0;

            if (ids.Count == 0)
            {
                lblTotal.Text = "Выберите хотя бы один товар.";
                picChart.Invalidate();
                return;
            }

            string idList = string.Join(",", ids);

            string sql = $@"
SELECT
    p.name,
    COALESCE(ord.ordered_sum,   0) AS ordered_sum,
    COALESCE(dlv.delivered_sum, 0) AS delivered_sum
FROM Product p
LEFT JOIN (
    SELECT oi.id_product,
           SUM(oi.quantity * oi.price) AS ordered_sum
    FROM OrderItem oi
    JOIN ClientOrder co ON co.id = oi.id_order
    WHERE co.order_date BETWEEN :df AND :dt
      AND oi.id_product IN ({idList})
    GROUP BY oi.id_product
) ord ON ord.id_product = p.id
LEFT JOIN (
    SELECT iii.id_product,
           SUM(iii.quantity * iii.price) AS delivered_sum
    FROM InvoiceInItem iii
    JOIN InvoiceIn ii ON ii.id = iii.id_invoice
    WHERE ii.invoice_date BETWEEN :df AND :dt
      AND iii.id_product IN ({idList})
    GROUP BY iii.id_product
) dlv ON dlv.id_product = p.id
WHERE p.id IN ({idList})
ORDER BY p.name";

            var da = new NpgsqlDataAdapter(sql, _con);
            da.SelectCommand.Parameters.AddWithValue("df", dtpFrom.Value.Date);
            da.SelectCommand.Parameters.AddWithValue("dt", dtpTo.Value.Date);
            var ds = new DataSet();
            da.Fill(ds);

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                string  name = row["name"].ToString()!;
                decimal ord  = Convert.ToDecimal(row["ordered_sum"]);
                decimal dlv  = Convert.ToDecimal(row["delivered_sum"]);
                _chartData.Add((name, ord, dlv));
                _totalOrdered   += ord;
                _totalDelivered += dlv;
            }

            double pct = _totalOrdered == 0 ? 0
                : Math.Round((double)_totalDelivered / (double)_totalOrdered * 100, 1);

            lblTotal.Text =
                $"Заказано: {_totalOrdered:N2} руб.   " +
                $"Доставлено: {_totalDelivered:N2} руб.   " +
                $"Выполнение: {pct}%";
            lblTotal.ForeColor = pct >= 100 ? Color.DarkGreen
                               : pct >= 50  ? Color.DarkOrange
                                            : Color.DarkRed;

            picChart.Invalidate();
        }

        // -------------------------------------------------------
        // Paint — двойная круговая диаграмма
        //
        // Левый круг:  доля каждого товара в ЗАКАЗАННОЙ сумме
        // Правый круг: доля каждого товара в ДОСТАВЛЕННОЙ сумме
        // Легенда снизу с цветами товаров + % заказан/доставлен
        // -------------------------------------------------------
        private void picChart_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.Clear(Color.White);

            int W = picChart.Width;
            int H = picChart.Height;

            // Палитра — по одному цвету на товар
            var palette = new[]
            {
                Color.FromArgb(70,  130, 210),
                Color.FromArgb(220, 80,  70),
                Color.FromArgb(80,  180, 80),
                Color.FromArgb(240, 170, 40),
                Color.FromArgb(150, 80,  200),
                Color.FromArgb(50,  190, 190),
                Color.FromArgb(230, 120, 50),
                Color.FromArgb(180, 50,  120),
            };

            if (_chartData.Count == 0 || (_totalOrdered == 0 && _totalDelivered == 0))
            {
                using var fnt = new Font("Segoe UI", 10F);
                g.DrawString("Нет данных за выбранный период", fnt, Brushes.Gray, 40, H / 2 - 10);
                return;
            }

            // Зона легенды снизу
            int legendH  = Math.Max(60, _chartData.Count * 20 + 30);
            int chartH   = H - legendH - 10;
            if (chartH < 60) chartH = 60;

            int diameter = Math.Min((W - 60) / 2, chartH - 20);
            if (diameter < 20) diameter = 20;

            int leftCX  = W / 4 - diameter / 2;
            int rightCX = 3 * W / 4 - diameter / 2;
            int topY    = (chartH - diameter) / 2;

            // ── Нарисовать два круга ──────────────────────────
            DrawPie(g, leftCX,  topY, diameter, _chartData,
                    d => d.Ordered,   palette, "Заказано");
            DrawPie(g, rightCX, topY, diameter, _chartData,
                    d => d.Delivered, palette, "Доставлено");

            // ── Вертикальный разделитель ──────────────────────
            using var penDiv = new Pen(Color.LightGray, 1);
            g.DrawLine(penDiv, W / 2, 5, W / 2, chartH - 5);

            // ── Легенда снизу ─────────────────────────────────
            int legY  = chartH + 6;
            int col1X = 12;
            int col2X = W / 2 + 12;
            int row   = 0;
            int colHalf = _chartData.Count / 2 + _chartData.Count % 2;

            using var fntLeg = new Font("Segoe UI", 8F);
            using var fntHdr = new Font("Segoe UI", 8F, FontStyle.Bold);

            // Заголовок легенды
            g.DrawString("Товар", fntHdr, Brushes.Black, col1X + 18, legY);
            g.DrawString("Заказ / Доставка", fntHdr, Brushes.Black, col1X + 160, legY);
            legY += 18;

            for (int i = 0; i < _chartData.Count; i++)
            {
                var (name, ord, dlv) = _chartData[i];
                var clr = palette[i % palette.Length];
                using var br = new SolidBrush(clr);

                double oPct = _totalOrdered   > 0 ? ord / (double)_totalOrdered   * 100 : 0;
                double dPct = _totalDelivered > 0 ? dlv / (double)_totalDelivered * 100 : 0;

                int lx = col1X;
                int ly = legY + (i % colHalf) * 20;
                if (i >= colHalf) { lx = col2X; ly = legY + (i - colHalf) * 20; }

                g.FillRectangle(br, lx, ly + 1, 13, 13);
                g.DrawRectangle(Pens.Gray, lx, ly + 1, 13, 13);

                string label = name.Length > 16 ? name[..15] + "…" : name;
                g.DrawString(label, fntLeg, Brushes.Black, lx + 17, ly);

                string nums = $"{oPct:F0}% / {dPct:F0}%";
                g.DrawString(nums, fntLeg, Brushes.DimGray, lx + 155, ly);
            }
        }

        // -------------------------------------------------------
        // Вспомогательный метод: нарисовать один круг с подписью
        // -------------------------------------------------------
        private static void DrawPie(
            Graphics g,
            int x, int y, int diameter,
            List<(string Name, decimal Ordered, decimal Delivered)> data,
            Func<(string, decimal, decimal), decimal> getValue,
            Color[] palette,
            string title)
        {
            decimal total = data.Sum(d => getValue(d));

            // Подпись над кругом
            using var fntTitle = new Font("Segoe UI", 9F, FontStyle.Bold);
            var titleSize = g.MeasureString(title, fntTitle);
            g.DrawString(title, fntTitle, Brushes.Black,
                x + diameter / 2f - titleSize.Width / 2f, y - 22);

            if (total == 0)
            {
                using var fntNo = new Font("Segoe UI", 8F);
                g.DrawEllipse(Pens.LightGray, x, y, diameter, diameter);
                g.DrawString("0 руб.", fntNo, Brushes.Gray,
                    x + diameter / 2f - 18f, y + diameter / 2f - 8f);
                return;
            }

            var rect = new Rectangle(x, y, diameter, diameter);
            float startAngle = -90f;
            int   idx        = 0;

            foreach (var item in data)
            {
                decimal val = getValue(item);
                if (val <= 0) { idx++; continue; }
                float sweep = (float)(val / total * 360f);
                using var brush = new SolidBrush(palette[idx % palette.Length]);
                g.FillPie(brush, rect, startAngle, sweep);
                using var pen = new Pen(Color.White, 2);
                g.DrawPie(pen, rect, startAngle, sweep);

                // Подпись процента внутри сегмента (если >= 7%)
                float pct = val / total * 100f;
                if (pct >= 7f)
                {
                    float midAngle = (startAngle + sweep / 2f) * (float)Math.PI / 180f;
                    float r        = diameter / 2f * 0.62f;
                    float tx       = x + diameter / 2f + r * (float)Math.Cos(midAngle);
                    float ty       = y + diameter / 2f + r * (float)Math.Sin(midAngle);
                    using var fntPct = new Font("Segoe UI", 7.5F, FontStyle.Bold);
                    var sz = g.MeasureString($"{pct:F0}%", fntPct);
                    g.DrawString($"{pct:F0}%", fntPct, Brushes.White, tx - sz.Width / 2, ty - sz.Height / 2);
                }

                startAngle += sweep;
                idx++;
            }

            // Сумма под кругом
            using var fntSum = new Font("Segoe UI", 8F);
            string sumStr = $"{total:N0} руб.";
            var sumSz = g.MeasureString(sumStr, fntSum);
            g.DrawString(sumStr, fntSum, Brushes.DarkBlue,
                x + diameter / 2f - sumSz.Width / 2f, y + diameter + 4);
        }

        private void btnRefresh_Click(object sender, EventArgs e)   => LoadAndDraw();
        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < clbProducts.Items.Count; i++)
                clbProducts.SetItemChecked(i, true);
        }
        private void btnDeselectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < clbProducts.Items.Count; i++)
                clbProducts.SetItemChecked(i, false);
        }
        private void btnClose_Click(object sender, EventArgs e) => Close();
    }

    // Вспомогательный класс для CheckedListBox
    internal class ProductItem
    {
        public int    Id   { get; }
        public string Name { get; }
        public ProductItem(int id, string name) { Id = id; Name = name; }
        public override string ToString() => Name;
    }
}
