namespace FedotovApp
{
    partial class FormRatioReport
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitle       = new Label();
            lblFrom        = new Label();
            lblTo          = new Label();
            dtpFrom        = new DateTimePicker();
            dtpTo          = new DateTimePicker();
            lblProducts    = new Label();
            clbProducts    = new CheckedListBox();
            btnSelectAll   = new Button();
            btnDeselectAll = new Button();
            btnRefresh     = new Button();
            btnClose       = new Button();
            picChart       = new PictureBox();
            lblTotal       = new Label();
            ((System.ComponentModel.ISupportInitialize)picChart).BeginInit();
            SuspendLayout();

            // ── Заголовок ─────────────────────────────────────
            lblTitle.Text      = "Диаграмма: соотношение заказанных и доставленных сумм";
            lblTitle.Font      = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTitle.AutoSize  = true;
            lblTitle.Location  = new Point(12, 10);

            // ── Период ────────────────────────────────────────
            lblFrom.Text     = "С:";
            lblFrom.Location = new Point(12, 50);
            lblFrom.AutoSize = true;

            dtpFrom.Location = new Point(40, 46);
            dtpFrom.Size     = new Size(140, 23);
            dtpFrom.Format   = DateTimePickerFormat.Short;

            lblTo.Text     = "По:";
            lblTo.Location = new Point(195, 50);
            lblTo.AutoSize = true;

            dtpTo.Location = new Point(220, 46);
            dtpTo.Size     = new Size(140, 23);
            dtpTo.Format   = DateTimePickerFormat.Short;

            btnRefresh.Text     = "Обновить";
            btnRefresh.Location = new Point(375, 44);
            btnRefresh.Size     = new Size(90, 27);
            btnRefresh.Click   += btnRefresh_Click;

            btnClose.Text     = "Закрыть";
            btnClose.Location = new Point(475, 44);
            btnClose.Size     = new Size(80, 27);
            btnClose.Click   += btnClose_Click;

            // ── Выбор товаров (левая панель) ──────────────────
            lblProducts.Text     = "Товары:";
            lblProducts.Font     = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblProducts.AutoSize = true;
            lblProducts.Location = new Point(12, 82);

            clbProducts.Location     = new Point(12, 100);
            clbProducts.Size         = new Size(200, 320);
            clbProducts.CheckOnClick = true;

            btnSelectAll.Text     = "Все";
            btnSelectAll.Location = new Point(12, 430);
            btnSelectAll.Size     = new Size(95, 25);
            btnSelectAll.Click   += btnSelectAll_Click;

            btnDeselectAll.Text     = "Снять все";
            btnDeselectAll.Location = new Point(117, 430);
            btnDeselectAll.Size     = new Size(95, 25);
            btnDeselectAll.Click   += btnDeselectAll_Click;

            // ── Диаграмма (правая зона) ───────────────────────
            picChart.Location    = new Point(225, 78);
            picChart.Size        = new Size(860, 390);
            picChart.BackColor   = Color.White;
            picChart.BorderStyle = BorderStyle.FixedSingle;
            picChart.Paint      += picChart_Paint;

            // ── Итоговая строка ───────────────────────────────
            lblTotal.Text      = "";
            lblTotal.Location  = new Point(225, 476);
            lblTotal.AutoSize  = true;
            lblTotal.Font      = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblTotal.ForeColor = Color.DarkBlue;

            // ── Форма ─────────────────────────────────────────
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode       = AutoScaleMode.Font;
            ClientSize          = new Size(1100, 510);
            Text                = "Диаграмма заказов и поставок — Федотов";
            Controls.AddRange(new Control[]
            {
                lblTitle,
                lblFrom, dtpFrom, lblTo, dtpTo,
                btnRefresh, btnClose,
                lblProducts, clbProducts,
                btnSelectAll, btnDeselectAll,
                picChart, lblTotal
            });
            Load += FormRatioReport_Load;
            ((System.ComponentModel.ISupportInitialize)picChart).EndInit();
            ResumeLayout(false);
        }

        private Label          lblTitle;
        private Label          lblFrom;
        private Label          lblTo;
        private DateTimePicker dtpFrom;
        private DateTimePicker dtpTo;
        private Label          lblProducts;
        private CheckedListBox clbProducts;
        private Button         btnSelectAll;
        private Button         btnDeselectAll;
        private Button         btnRefresh;
        private Button         btnClose;
        private PictureBox     picChart;
        private Label          lblTotal;
    }
}
